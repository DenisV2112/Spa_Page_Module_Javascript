
function register() {
  const email = document.getElementById('email').value.toLowerCase();
  const username = document.getElementById('userName').value.toLowerCase();
  const password = document.getElementById('password').value;
  const name = document.getElementById('name').value;
  const lastname = document.getElementById('lastname').value;

  let users = JSON.parse(localStorage.getItem("users")) || {};

  // Validation
  if (!email || !username || !password || !name || !lastname) {
    alert("Todos los campos son obligatorios."); 
    return;
  }

  // Validate duplicate
  const emailExists = users[email] !== undefined;
  const usernameExists = Object.values(users).some(u => u.userName === username);

  if (emailExists) {
    alert("Este correo ya está registrado. Usa otro o inicia sesión.");
    return;
  }

  if (usernameExists) {
    alert("Este Username ya está registrado. Usa otro o inicia sesión.");
    return;
  }

  // save users
  const newUser = {
    name,
    userName: username,
    lastname,
    password,
    email,
    role: "user"  
  };

  users[email] = newUser;
  localStorage.setItem("users", JSON.stringify(users));

  sessionStorage.setItem("authUser", JSON.stringify(newUser));

  alert("Usuario registrado con éxito.");
  window.location.hash = "#/home";  

  document.getElementById("name").value = "";
  document.getElementById("userName").value = "";
  document.getElementById("lastname").value = "";
  document.getElementById("email").value = "";
  document.getElementById("password").value = "";
}
