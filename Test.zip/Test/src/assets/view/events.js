import { END_POINT } from "../scripts/config.js";
import createEvent from "../scripts/createEvents.js";
const user = JSON.parse(sessionStorage.getItem("authUser"));
async function event() { //show all events registed at db.json
    try {
      const res = await fetch(`${END_POINT}/events`);
      const allEvents = await res.json();

      console.log(allEvents);
      const container = document.getElementById("main");
      const addButton = document.getElementById("addButton");
        const eventId = '';
      if (allEvents.length === 0) {
        container.innerHTML = `<p class="text-gray-500">No tienes Eventos registrados.</p>`;
        return;
      }
      addButton.innerHTML =`${user.role==="admin"?`<button id="newEvent" class="btn btn-outline-light">Add</button> `:``}`;
      container.innerHTML = allEvents.map(events => `
        
        <div class="border rounded-lg p-4 hover:shadow-md transition p-8 rounded-xl border border-gray-200">
          <span class="material-icons text-gray-500 mb-4" style="font-size: 2rem;">
            description
          </span>
          <h3 class="font-semibold mt-2">${events.tittle}</h3>
          <p class="text-sm text-gray-600">${events.description}</p>
          <p class="text-sm text-gray-600">${events.date}</p>
          <p class="text-sm text-gray-600">${events.capacity}</p>
      ${user.role === "admin"? `<button id="deleteButton">Delete</button> `:`<button data-id=${events.id} id="enrollButton">Enroll</button>`}
        </div>
      `
    
    );
    if(document.getElementById("newEvent") !== null){
        document.getElementById("newEvent").addEventListener("click", createEvent)
    }
  

  if(document.getElementById("enrollButton") !== null){
     const enrollButton = document.getElementById("enrollButton");
    
        document.querySelectorAll("enrollButton").forEach(button => { 
        enrollButton.addEventListener("click",  function(events) {
         const id = button.dataset.id;
        events.preventDefault();
        if (allEvents.registered === undefined || allEvents.capacity <= allEvents.registered.length) {

                 const edit =  fetch(`http://localhost:3001/events/${id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                          "id": edit.id,
                            "tittle": edit.title,
                            "description": edit.description,
                            "capacity":edit.capacity,
                            "date" : edit.date,
                        "registered": edit.registered.push(user.email)

                    }),
                });
    }
    })})}
      ; 
          

    } catch (err) {
      console.error("Error cargando notas:", err);
    }
}

export default event;
