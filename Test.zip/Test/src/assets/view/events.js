import { END_POINT } from "../scripts/config.js";
import createEvent from "../scripts/createEvents.js";
const user = JSON.parse(sessionStorage.getItem("authUser"));
async function event() {
    try {
      const res = await fetch(`${END_POINT}/events`);
      const allEvents = await res.json();

      console.log(allEvents);
      const container = document.getElementById("main");
      const addButton = document.getElementById("addButton");

      if (allEvents.length === 0) {
        container.innerHTML = `<p class="text-gray-500">No tienes Eventos registrados.</p>`;
        return;
      }
      addButton.innerHTML =`${user.role==="admin"?`<button id="newEvent" class="btn btn-outline-light">Add</button> `:``}`;
      container.innerHTML = allEvents.map(events => `
        
        <div class="border rounded-lg p-4 hover:shadow-md transition p-8 rounded-xl border border-gray-200">
          <span class="material-icons text-gray-500 mb-4" style="font-size: 2rem;">
            description
          </span>
          <h3 class="font-semibold mt-2">${events.tittle}</h3>
          <p class="text-sm text-gray-600">${events.description}</p>
          <p class="text-sm text-gray-600">${events.date}</p>
          <p class="text-sm text-gray-600">${events.capacity}</p>
      ${user.role === "admin"? `<button id="deleteButton">Delete</button> `:`<button id="enrollButton">Enroll</button>`}
        </div>
      `
    
    )
    if(document.getElementById("newEvent") !== null){
        document.getElementById("newEvent").addEventListener("click", createEvent)
    }
  

  if(document.getElementById("enrollButton") !== null){
     const enrollButton = document.getElementById("enrollButton");
    enrollButton.addEventListener("click",  function(events) {
        console.log(events);
        events.preventDefault();
        if (allEvents.registered === undefined || allEvents.capacity <= allEvents.registered.length) {

                 const edit =  fetch(`http://localhost:3001/events/2`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                          "id": edit.id,
                            "tittle": edit.title,
                            "description": edit.description,
                            "capacity":edit.capacity,
                            "date" : edit.date,
                        "registered": edit.registered.push(user.email)

                    }),
                });
    }
    })}
      ; 
          

    } catch (err) {
      console.error("Error cargando notas:", err);
    }
}

export default event;

/*

  container.innerHTML = '';
  events.forEach((event, index) => {
    const i = index;
    const li = document.createElement('li');
    li.innerHTML = ` 
      <strong>${event.title}</strong> (${event.date})<br>
      ${event.description}<br>
      Capacity: ${event.capacity}<br>
      ${user.role === "admin"? `<button id="deleteButton">Delete</button> `:`<button id="enrollButton">Enroll</button>`}
    `;
    container.appendChild(li);
    if(user.role==="admin"){
        let adminButton = document.getElementById("deleteButton");
    adminButton.addEventcontainerener("click", function(i) {
        if (confirm("Are you sure you want to delete this event?")) {
    events.splice(i, 1);
    localStorage.setItem('events', JSON.stringify(events));
    renderEvents();
  }
  })}
  else{
     let enrollButton = document.getElementById("enrollButton");
    enrollButton.addEventcontainerener("click", function(i) {
        if (confirm("Are you sure you want to delete this event?")) {
    events.splice(i, 1);
    localStorage.setItem('events', JSON.stringify(events));
    renderEvents();
    }
    })}

  });
*/ 