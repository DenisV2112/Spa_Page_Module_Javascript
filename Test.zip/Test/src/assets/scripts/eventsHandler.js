let events = JSON.parse(localStorage.getItem('events')) || [];

const form = document.getElementById('event-form');
const list = document.getElementById('event-list');

// Render all events
function renderEvents() {
  list.innerHTML = '';
  events.forEach((event, index) => {
    const li = document.createElement('li');
    li.innerHTML = ` 
      <strong>${event.title}</strong> (${event.date})<br>
      ${event.description}<br>
      Capacity: ${event.capacity}<br>
      <button onclick="deleteEvent(${index})">Delete</button>
    `;
    list.appendChild(li);
  });
}

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const newEvent = {
    title: form.title.value,
    description: form.description.value,
    usersRegistered: parseInt(form.usersRegistered.value),
    date: form.date.value,
    capacity: parseInt(form.capacity.value)
  };

  if (form.dataset.editingIndex) {
    const idx = parseInt(form.dataset.editingIndex);
    events[idx] = newEvent;
    delete form.dataset.editingIndex;
    form.querySelector('button').textContent = 'Add Event';
  } else {
    events.push(newEvent);
  }

  localStorage.setItem('events', JSON.stringify(events));
  renderEvents();
  form.reset();
});

function deleteEvent(index) {
  if (confirm("Are you sure you want to delete this event?")) {
    events.splice(index, 1);
    localStorage.setItem('events', JSON.stringify(events));
    renderEvents();
  }
}

// Inicial render
renderEvents();
    