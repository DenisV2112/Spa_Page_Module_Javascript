



 const user = JSON.parse(sessionStorage.getItem("authUser"));
  if (!user) {
    window.location.href = "/src/assets/components/pages/login.html";
  }
    /*


// 2. Lógica de la modal (abrir, cerrar, guardar)
document.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("note-modal");
  const openBtn = document.getElementById("open-note-modal");
  const cancelBtn = document.getElementById("cancel-modal");
  const saveBtn = document.getElementById("save-note");

  if (!modal || !openBtn || !cancelBtn || !saveBtn) {
    console.warn("⚠️ Elementos del modal no encontrados en el DOM");
    return;
  }

  openBtn.addEventListener("click", () => {
    modal.classList.remove("hidden");
  });

  cancelBtn.addEventListener("click", () => {
    modal.classList.add("hidden");
  });

  saveBtn.addEventListener("click", () => {
    const title = document.getElementById("modal-title").value.trim();
    const content = document.getElementById("modal-content").value.trim();

    if (!title || !content) {
      return alert("Completa todos los campos.");
    }

    createNote(title, content);

    modal.classList.add("hidden");
    document.getElementById("modal-title").value = "";
    document.getElementById("modal-content").value = "";
  });
});*/